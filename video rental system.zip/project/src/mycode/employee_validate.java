/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mycode;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Shakhila Pranieth
 */
public class employee_validate {
    
     public static boolean checkemployee(String name,String password,PreparedStatement ps,Connection con){
        
        try{
            String sql = "SELECT COUNT(*) FROM employee where name = '"+name+"' AND password = '"+password+"'";
            ps = con.prepareStatement(sql);
            ResultSet r1 = ps.executeQuery();
            
            r1.next();
            
            if(r1.getInt("COUNT(*)")==1){
                return true;
            }
        }
        catch(Exception e){
             
        }
        return false;  
    }
     //between
     public static boolean checkadmin(String name, String password,PreparedStatement ps,Connection con)
     {
     try
     {
     String sql = "SELECT COUNT(*) FROM admin where name = '"+name+"' AND password = '"+password+"'";
     ps = con.prepareStatement(sql);
     ResultSet r1 = ps.executeQuery();
     
     r1.next();
     
     if(r1.getInt("COUNT(*)")==1)
     {
         return true;
     }
     }
         
     catch(Exception e)
     {
     
     }
        return false; 
     }
    
}
